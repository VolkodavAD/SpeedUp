/**
 * GeoLocation
 *
 * Copyright (c) 2016 Steven Thompson
**/

#include "GeoLocationProvider.h"

void AGeoLocationProvider::Setup(UWorld* validWorld)
{
	this->world = validWorld;
}

void AGeoLocationProvider::CheckPermissions()
{
}
